﻿namespace Exercises.Models
{
    public class Licence
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public Resource Resource { get; set; }
    }
}
