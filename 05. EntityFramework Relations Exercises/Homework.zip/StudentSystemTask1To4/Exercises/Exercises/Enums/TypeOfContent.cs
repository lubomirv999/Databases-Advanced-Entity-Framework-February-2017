﻿namespace Exercises.Enums
{
    public enum ContentType
    {
        Application,
        Pdf,
        Zip
    }
}
