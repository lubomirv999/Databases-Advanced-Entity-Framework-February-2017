﻿namespace Exercises.Enums
{
    public enum ResourceType
    {
        Video,
        Presentation,
        Document,
        Other
    }
}
