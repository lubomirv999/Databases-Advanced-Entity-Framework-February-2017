﻿namespace ExamPrep.Data.DTO
{
    public class AnomalyDto
    {
        public string OriginPlanet { get; set; }
        public string TeleportPlanet { get; set; }
    }
}
