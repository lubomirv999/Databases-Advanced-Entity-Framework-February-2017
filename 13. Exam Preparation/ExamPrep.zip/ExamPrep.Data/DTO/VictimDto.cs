﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamPrep.Data.DTO
{
    public class VictimDto
    {
        public int Id { get; set; }
        public string Person { get; set; }
    }
}
