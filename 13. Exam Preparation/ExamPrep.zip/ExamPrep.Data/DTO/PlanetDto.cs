﻿namespace ExamPrep.Data.DTO
{
    public class PlanetDto
    {
        public string Name { get; set; }
        public string Sun { get; set; }
        public string SolarSystem { get; set; }
    }
}
