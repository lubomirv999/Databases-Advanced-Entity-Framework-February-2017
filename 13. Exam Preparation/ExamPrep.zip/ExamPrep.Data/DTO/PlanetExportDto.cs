﻿namespace ExamPrep.Data.DTO
{
    public class PlanetExportDto
    {
        public string Name { get; set; }
    }
}
