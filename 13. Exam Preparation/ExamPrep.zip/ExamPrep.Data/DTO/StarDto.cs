﻿namespace ExamPrep.Data.DTO
{
    public class StarDto
    {
        public string Name { get; set; }
        public string SolarSystem { get; set; }
    }
}
