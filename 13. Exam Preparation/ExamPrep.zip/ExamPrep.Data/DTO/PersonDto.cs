﻿namespace ExamPrep.Data.DTO
{
    public class PersonDto
    {
        public string Name { get; set; }
        public string HomePlanet { get; set; }
    }
}
