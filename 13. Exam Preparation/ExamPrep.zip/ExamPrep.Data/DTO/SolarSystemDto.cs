﻿namespace ExamPrep.Data.DTO
{
    public class SolarSystemDto
    {
        public string Name { get; set; }
    }
}
