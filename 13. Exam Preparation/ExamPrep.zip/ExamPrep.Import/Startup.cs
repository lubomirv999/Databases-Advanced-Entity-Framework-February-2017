﻿namespace ExamPrep.Import
{
    class Startup
    {
        static void Main(string[] args)
        {
            //JsonImport.ImportSolarSystems();
            //JsonImport.ImportStars();
            //JsonImport.ImportPlanets();
            //JsonImport.ImportPeople();
            //JsonImport.ImportAnomalies();
            //JsonImport.ImportVictims();
            XmlImport.ImportAnomalies();
        }
    }
}
