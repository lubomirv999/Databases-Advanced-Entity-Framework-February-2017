﻿namespace ExamPrep.Export
{
    class Startup
    {
        static void Main(string[] args)
        {
            JsonExport.ExportPlanets();
        }
    }
}
