﻿namespace ProductsShop
{
    internal class CategoryDto
    {
    }
}