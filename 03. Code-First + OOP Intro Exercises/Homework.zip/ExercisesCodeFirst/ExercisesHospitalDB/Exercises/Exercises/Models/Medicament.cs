﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises.Models
{
    class Medicament
    {
        public class Medicament
        {
            public int Id { get; set; }
            public string Name { get; set; }
        }
    }
}
