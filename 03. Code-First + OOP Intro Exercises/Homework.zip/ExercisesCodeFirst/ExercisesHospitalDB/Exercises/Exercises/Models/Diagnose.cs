﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercises.Models
{
    class Diagnose
    {
        public class Diagnose
        {
            public int Id { get; set; }

            public string Name { get; set; }

            public string Comment { get; set; }
        }
    }
}
