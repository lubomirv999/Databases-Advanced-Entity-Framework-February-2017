﻿namespace PlanetHunters.Client
{
    using Data;

    class Startup
    {
        static void Main(string[] args)
        {
            //Init method for creating the DB
            //Utility.InitDB();
        }
    }
}
