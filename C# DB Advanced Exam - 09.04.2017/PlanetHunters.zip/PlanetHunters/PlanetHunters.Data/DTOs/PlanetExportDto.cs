﻿namespace PlanetHunters.Data.DTOs
{
    public class PlanetExportDto
    {
        public string Name { get; set; }
    }
}
