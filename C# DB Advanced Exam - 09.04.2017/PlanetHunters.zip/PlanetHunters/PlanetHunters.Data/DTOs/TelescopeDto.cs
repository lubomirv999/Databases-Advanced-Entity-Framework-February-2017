﻿namespace PlanetHunters.Data.DTOs
{
    public class TelescopeDto
    {
        public string Name { get; set; }

        public string Location { get; set; }

        public double MirrorDiameter { get; set; }
    }
}
