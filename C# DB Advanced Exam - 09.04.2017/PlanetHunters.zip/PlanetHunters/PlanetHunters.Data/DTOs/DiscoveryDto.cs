﻿namespace PlanetHunters.Data.DTOs
{
    public class DiscoveryDto
    {
        public string Stars { get; set; }

        public string Planets { get; set; }

        public string Pioneers { get; set; }

        public string Observers { get; set; }
    }
}
