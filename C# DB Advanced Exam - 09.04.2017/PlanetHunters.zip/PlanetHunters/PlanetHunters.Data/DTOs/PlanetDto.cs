﻿namespace PlanetHunters.Data.DTOs
{
    public class PlanetDto
    {
        public string Name { get; set; }

        public double Mass { get; set; }

        public string StarSystem { get; set; }
    }
}
