﻿namespace PlanetHunters.Data.DTOs
{
    public class StarDto
    {
        public string Name { get; set; }

        public double Temperature { get; set; }

        public string StarSystem { get; set; }
    }
}
