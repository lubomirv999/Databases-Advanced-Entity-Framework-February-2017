﻿namespace PlanetHunters.Import
{
    class Startup
    {
        static void Main(string[] args)
        {
            //Importing Json

            //Importing Astronomers
            //JsonImport.ImportAstronomers();

            //Importing Telescopes
            //JsonImport.ImportTelescopes();

            //Importing Planets
            //JsonImport.ImportPlanets();

            //Importing XML

            //Importing Stars
            //XmlImport.ImportStars();

            //Importing Discoveries
            //XmlImport.ImportDiscoveries();
        }
    }
}
