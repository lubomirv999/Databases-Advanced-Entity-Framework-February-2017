﻿namespace PlanetHunters.Export
{
    class Startup
    {
        static void Main(string[] args)
        {
            //Exporting Json

            //Exporting Planets
            //JsonExport.ExportPlanets();

            //Exporting Astronomers
            //JsonExport.ExportAstronomers();
        }
    }
}
